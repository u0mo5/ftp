pretty
======

通过分析百度图片的API，获取百度图片并展示。

* 后台图片获取基于PHP的Reques library https://github.com/rmccue/Requests 
* 前台页面展示基于Jquery和其瀑布的插件
